<?php

require_once QODE_CORE_ABS_PATH . '/post-types/portfolio/portfolio-register.php';
require_once QODE_CORE_ABS_PATH . '/post-types/portfolio/shortcodes/portfolio-list.php';
require_once QODE_CORE_ABS_PATH . '/post-types/portfolio/shortcodes/portfolio-slider.php';

require_once QODE_CORE_ABS_PATH . '/post-types/testimonials/testimonials-register.php';
require_once QODE_CORE_ABS_PATH . '/post-types/testimonials/shortcodes/testimonials.php';

require_once QODE_CORE_ABS_PATH . '/post-types/carousels/carousel-register.php';
require_once QODE_CORE_ABS_PATH . '/post-types/carousels/shortcodes/carousel.php';

require_once QODE_CORE_ABS_PATH . '/post-types/slider/slider-register.php';
require_once QODE_CORE_ABS_PATH . '/post-types/slider/tax-custom-fields.php';
require_once QODE_CORE_ABS_PATH . '/post-types/slider/shortcodes/slider.php';

require_once QODE_CORE_ABS_PATH . '/post-types/post-types-register.php'; //this has to be loaded last