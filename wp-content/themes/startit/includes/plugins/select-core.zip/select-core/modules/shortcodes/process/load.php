<?php

require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/process/process-holder.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/process/process-item.php';