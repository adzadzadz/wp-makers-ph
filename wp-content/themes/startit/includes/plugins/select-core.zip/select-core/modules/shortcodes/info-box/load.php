<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/info-box/info-box.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/info-box/custom-styles/info-box.php';