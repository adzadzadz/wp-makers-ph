<?php
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/clients/clients.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/clients/client.php';
