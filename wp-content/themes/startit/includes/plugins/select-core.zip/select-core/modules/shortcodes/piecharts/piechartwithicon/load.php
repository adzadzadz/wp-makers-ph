<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartwithicon/pie-chart-with-icon.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartwithicon/custom-styles/pie-chart-with-icon.php';