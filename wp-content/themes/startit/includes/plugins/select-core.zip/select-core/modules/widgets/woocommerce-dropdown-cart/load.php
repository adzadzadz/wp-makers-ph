<?php
if ( startit_qode_is_plugin_installed( 'woocommerce' ) ) {
	require_once QODE_CORE_MODULES_ABS_PATH . '/widgets/woocommerce-dropdown-cart/woocommerce-dropdown-cart.php';
}
