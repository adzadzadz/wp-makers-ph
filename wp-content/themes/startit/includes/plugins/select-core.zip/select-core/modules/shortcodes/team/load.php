<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/team/team.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/team/custom-styles/team.php';