<?php
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/elements-holder/elements-holder.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/elements-holder/elements-holder-item.php';
