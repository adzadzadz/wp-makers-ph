<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartbasic/pie-chart-basic.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartbasic/custom-styles/pie-chart-basic.php';